<?php require_once './config/config.php'; ?>

<?php
if(isset($_POST['delete'])) {
	$Title = mysqli_real_escape_string($Connection, $_POST['Title']);
	$Slug = mysqli_real_escape_string($Connection, $_POST['Slug']);
	$Category = mysqli_real_escape_string($Connection, $_POST['Category']);
	$Content = mysqli_real_escape_string($Connection, $_POST['Content']);
	date_default_timezone_set("Asia/Ho_Chi_Minh");
	$currentTime = time();
	$dateTime = strftime("%d-%m-%Y", $currentTime);
	$dateTime;
	$Admin = "TuanIT";
	$Image = $_FILES["Image"]["name"];
	$Target = "upload/".basename($_FILES["Image"]["name"]);	
    global $Connection;
    $DeleteFromURL = $_GET['delete'];
    $Query = "DELETE FROM post WHERE idpost = '$DeleteFromURL'";
    $Execute = mysqli_query($Connection, $Query);
    move_uploaded_file($_FILES["Image"]["tmp_name"], $Target); // Chuyen hinh anh sang thu muc
    if ($Execute) {
        $_SESSION["SuccessMessage"] = "Post Deleted Successfully";
        Redirect_to("dashboard.php");
    } else {
        $_SESSION["ErrorMessage"] = "Something Went Wrong. Try Again !";
        Redirect_to("dashboard.php");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>DeletePost</title>
	<link rel="shortcut icon" href="../favicon.ico">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="../css/fontawesome.css">
	<link rel="stylesheet" href="../css/adminstyle.css">
	<style type="text/css">
		.FieldInfo {
			color: rgb(251, 174, 44);
			font-family: Bitter, Georgia, "Times New Roman", Times, serif;
			font-size: 1.2em;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container">
		<div class="navbar-header">
	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
		data-target="#collapse">
		<span class="sr-only">Toggle Navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
	<a class="navbar-brand" href="blog.php">
	   <img style="margin-top: -12px;" src="">
	</a>
		</div>
		<div class="collapse navbar-collapse" id="collapse">
		<ul class="nav navbar-nav">
			<li><a href="#">Home</a></li>
			<li class="active"><a href="../index.php" target="_blank">Blog</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="#">Services</a></li>
			<li><a href="#">Contact Us</a></li>
			<li><a href="#">Feature</a></li>
		</ul>
		<form action="blog.php" class="navbar-form navbar-right">
		<div class="form-group">
		<input type="text" class="form-control" placeholder="Search" name="Search" >
		</div>
	         <button class="btn btn-default" name="SearchButton">Search</button>		
		</form>
		</div>		
	</div>
</nav>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
			<h1>TuanIT</h1>
			<ul id="Side_Menu" class="nav nav-pills nav-stacked">
				<li><a href="dashboard.php"><span class="glyphicon glyphicon-home"></span>&nbsp; DashBoard</a></li>
				<li class="active"><a href="addnewpost.php"><span class="glyphicon glyphicon-list-alt"></span>&nbsp; Add New Post</a></li>
				<li><a href="categories.php"><span class="glyphicon glyphicon-tags"></span>&nbsp; Categories</a></li>
				<li><a href="admins.php"><span class="glyphicon glyphicon-user"></span>&nbsp; Manage Admins</a></li>
				<li><a href="#"><span class="fas fa-users"></span>&nbsp; User</a></li>
				<li>
					<a href="comments.php"><span class="glyphicon glyphicon-comment"></span>&nbsp; Comments
					<?php
					$QueryApproved = "SELECT COUNT(*) FROM comment WHERE status = 'OFF'";
					$ExecuteApproved  = mysqli_query($Connection, $QueryApproved);
					$RowApproved  = mysqli_fetch_array($ExecuteApproved );
					$TotalApproved  = array_shift($RowApproved);
					if ($TotalApproved > 0) { ?>
						<span class="label label-warning pull-right"><?= $TotalApproved; ?></span>
					<?php
					}
					?>
					</a>
				</li>
				<li><a href="#"><span class="glyphicon glyphicon-equalizer"></span>&nbsp; Live Blog</a></li>
				<li><a href="#"><span class="fas fa-compact-disc"></span>&nbsp; Media</a></li>
				<li><a href="#"><span class="glyphicon glyphicon-log-out"></span>&nbsp; Logout</a></li>
			</ul>
		</div> <!-- End Side Area -->
		<div class="col-sm-10">
			<h1>Delete Post</h1>
			<?php
				echo Message();
				echo SuccessMessage();
			?> 
			<div>
				<?php
				$SearchQueryParameter = $_GET["delete"];
				$Query = "SELECT * FROM post, category WHERE idpost = '$SearchQueryParameter' AND post.idcategory = category.id";
				$ExecuteQuery = mysqli_query($Connection, $Query);
				while ($DataRows = mysqli_fetch_array($ExecuteQuery)) {
					$TitleDelete = $DataRows["title"];
					$SlugDelete = $DataRows["slug"];
					$CategoryDelete  = $DataRows["namecategory"];
					$ImageDelete = $DataRows["images"];
					$ContentDelete = $DataRows["content"];
				}
				?>
				<form action="deletepost.php?delete=<?= $SearchQueryParameter; ?>" method="post" enctype="multipart/form-data">
					<fieldset>
						<div class="form-group">
							<label for="title"><span class="FieldInfo">Title:</span></label>
							<input disabled value="<?= $TitleDelete; ?>" class="form-control" type="text" name="Title" id="title" placeholder="Title">
						</div>
						<div class="form-group">
							<label for="slug"><span class="FieldInfo">Slug:</span></label>
							<input disabled value="<?= $SlugDelete; ?>" class="form-control" type="text" name="Slug" id="slug" placeholder="Slug">
						</div>
						<div class="form-group">
							<span class="FieldInfo">Existing Category:</span>
							<?= $CategoryDelete; ?> <br>
							<label for="categoryselect"><span class="FieldInfo">Category:</span></label>
							<select disabled class="form-control" name="Category" id="categoryselect" value="Category">
								<?php
								global $Connection;
								$ViewQuery = "SELECT * FROM category";
								$Execute = mysqli_query($Connection, $ViewQuery);
								while ($DataRows = mysqli_fetch_array($Execute)) {
									$Id = $DataRows["id"];
									$CategoryName = $DataRows["namecategory"];
									?>
									<option value=""><?php echo $CategoryName; ?></option>
									<?php
								}
								?>
							</select>
						</div>
						<div class="form-group">
							<span class="FieldInfo">Existing Image:</span>
							<img src="../upload/<?= $ImageDelete; ?>" width="120px;" height="50px;"> <br>
							<label for="imageselect"><span class="FieldInfo">Select Image:</span></label>
							<input disabled type="file" class="form-control" name="Image" id="imageselect">
						</div>

						<div class="form-group">
							<label for="postarea"><span class="FieldInfo">Post:</span></label>
							<textarea disabled class="form-control" name="Post" id="postarea" col="10" rows="20">
								<?= $ContentDelete; ?>
							</textarea>
						</div>
						<input type="submit" class="btn btn-danger btn-block" name="delete" value="Delete" Post">
					</fieldset> 
				</form>
			</div>	
		</div> <!-- End Main Area -->
	</div> <!-- End Row -->
</div> <!-- End Container -->

<div class="footer">
	<p style="color: #838383; text-align: center;">&copy; &nbsp;2018</p>
</div>
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../tinymce/js/tinymce/tinymce.min.js"></script>
<script src="../js/tiny.js"></script>
</body>
</html>