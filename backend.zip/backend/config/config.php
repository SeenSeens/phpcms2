<?php require_once './config/db.php'; ?>
<?php require_once './config/sessions.php'; ?>
<?php require_once './config/functions.php'; ?>